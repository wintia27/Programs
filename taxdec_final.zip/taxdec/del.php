<?php
       include('db_connect.php');
       
?>  
<body>
<?php
	//check for connection error
	$sql = 'SELECT * FROM record WHERE tdrp_id ='.$_GET['id'];
	$query=mysqli_query($conn,$sql) or die(mysqli_error($db));
	$row=mysqli_fetch_array($query);

	// if(isset($_GET['tdrp_id']))

	if (!isset($_GET['do']) || $_GET['do'] != 1) {
										
			
			switch ($_GET['type']) {
				case 'record':
					$query1 = 'DELETE FROM record
							WHERE
							tdrp_id = ' . $_GET['id'];
						$result = mysqli_query($conn, $query1) or die(mysqli_error($conn));

		$file_name = $row['file_name'];
		$path = "assets/record/".$file_name;

		if (!unlink($path)){
			echo "You have an error!";
		// } else{
		// 	echo "You have succesfully Deleted!";
		// 	header("Location: index.php?page=record");
		}
		

	?>

	<script type="text/javascript">
	alert("Successfully Deleted.");
	window.location = "index.php?page=record";
	</script>				
					
	<?php
	//break;
				}
			}
?>