<?php
       include('db_connect.php');
        ?>  

<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="assets/datatable1/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/datatable1/css/datatables.min.css">
    <link rel="stylesheet" href="assets/datatable1/css/style.css">

  <style type="text/css">
    .container{
      margin-top:10px;
      border:5px;
      border-color:black;
      
    }
    .table{
        background-color:#fafafa;
        -moz-box-shadow:0 3px 3px 0 rgba(0,0,0,.7);
        -webkit-box-shadow:0 3px 3px 0 rgba(0,0,0,.7);
        box-shadow:0 3px 3px 0 rgba(0,0,0,.7);
        border-radius:7;
    }
    .left_panel{
        overflow: hidden;
        border-radius: 7px;
        -webkit-box-shadow:0px 0px 20px 0px rgba(50,50,50,0.57);
        -moz-box-shadow:0px 0px 20px 0px rgba(50,50,50,0.57);
        height:auto;
        width: 80px;
    }

    /* .filterhead{
        width:50px;
    } */
  </style>
</head>

<body>
<section>
    <div class="content-body">   
        <div class="container-fluid">
        <h3 class="text-left">List of Tax Decleration of Real Property</h3>
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="data_table">
                            <table id="example" class="table table-bordered table-striped">
                                <thead>
                                    <tr class="table-dark">
                                        <th class="filterhead">OWNER NAME</th>
                                        <th class="filterhead"></th>
                                        <th class="filterhead">BARANGAY</th>
                                        <th class="filterhead">YEAR</th>
                                        <th class="filterhead"></th>
                                    </tr>
                                    <tr>
                                        <th>OWNER NAME</th>
                                        <th>TD NUMBER</th>
                                        <th>BARANGAY</th>
                                        <th>YEAR</th>
                                        <th>ACTION</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php                  
                                    $query = 'SELECT * FROM record ORDER BY tdrp_id DESC';
                                    $result = mysqli_query($conn, $query) or die (mysqli_error($conn));



                                    while ($row = mysqli_fetch_assoc($result)) {

                                    echo '<tr>';
                                    echo '<td>'. $row['fname'].' '.$row['lname'].'</td>';
                                    echo '<td>'. $row['taxnum'].'</td>';
                                    echo '<td>'. $row['barangay'].'</td>';
                                    echo '<td>'. $row['tdyear'].'</td>';
                                    echo '<td> <a type="button" class="btn btn-xs btn-info" href="searchfrm.php?action=edit & id='.$row['tdrp_id'] . '" >View <i class="fa fa-eye"></i></a> ';
                                    echo '<a  type="button" class="btn btn-xs btn-warning" style=" justify-items: center;" href="edit.php?action=edit & id='.$row['tdrp_id'] . '">Edit <i class="fa fa-edit"></i></a> ';
                                    echo '<a  type="button" class="btn btn-xs btn-danger" style="justify-items: center;"href="del.php?type=record&delete & id='.$row['tdrp_id'] . '">Delete <i class="fa fa-trash"></i></a> </td>';
                                    echo '</tr> ';

                                    }
                                    ?>        
                                                  
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>
</body>

</html>
    

<script>  
    $(document).ready(function(){  
        $('#example').DataTable( );  
    }); 

   
</script>

