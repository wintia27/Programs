<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Admin | Blog Site</title>

<?php include('./header.php'); ?>
<?php 
session_start();
if(isset($_SESSION['login_id']))
header("location:index.php?page=home");
?>

</head>

<style>
	
	@media screen and (max-width: 800px) {
		.leftcolumn, .rightcolumn {
			width: 100%;
			padding: 0;
		}
	}
	body{
		width: 100%;
	    height: 100%;
	    /*background: #007bff;*/
		font-family: Arial;
		color: #1E1E24;
	}
	main#main{
		width:100%;
		height: 100%;
		/* background:white; */
	}
	#login{
		/* float: right; */
		display: flex;
		justify-content: center;
		align-items: center;
		padding-top: 50px; 
	}

	/* #login-left{
		float: left;
  		width: 60%;
		height: 150%;
		background: white;
		position: absolute;
		left:0;
		width:60%;
		
		align-items: center;
	} */
	#login .card{
		background-color: #FFFFFF;
		padding: 20px;
		margin-top: 20px;
	}
	/* */
	.button {
		background-color: #111D4A; /* Space Cadet*/
		border: none;
		color: white;
		padding: 15px 32px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 16px;
		padding: 8px 20px;
		border-radius: 0;
		overflow: hidden;
	}

	.button:hover {
		background: transparent;
		box-shadow: 0 0 20px 10px hsla(204, 70%, 53%, 0.5);
	}
	.card {
		width: 900px;
		background: #FFF;
		border-radius: 10px;
		overflow: hidden;
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		padding: 70px 60px;
		align-items: center;
	}
	.login-form {
		margin-left: 80px;
	}

	/* column and row */
	.column {
	float: left;
	width: 50%;
	padding: 10px;
	}
	.row:after {
	content: "";
	display: table;
	clear: both;
	}
	.left, .right {
		width: 25%;
	}

	.middle {
		width: 50%;
	}

	/* login-form */
	.login-form {
		margin-left: 80px;
	}
	.login-form h4 {
		font-size: 32px;
		text-align: center;
		margin-bottom: 10px;
		text-transform: capitalize;
		color: #555
	}
	.form-group .form-control {
      background-color: #e6e6e6;
      padding: 11px 20px 11px 65px;
      color: #666;
      border-radius: 50px;
      font-size: 17px;
      font-family: 'arial';
      border-top-right-radius: 50px !important;
      border-bottom-right-radius: 50px !important;
      transition: all .2s ease-in-out;
      outline: none !important;
      box-shadow: none;
      border-color: #DDD
  }

  /* images */
  .pic1 {
		/* margin: auto; */
		/* font-size: 20em; */
		background: url("./assets/img/backg.png");
		background-repeat: no-repeat;
  		background-size: 100% 100%;
		height: 400px;
		width: 500px;
		padding: 20px;
		color: #000000b3;
		display: flex;
		/* align-items: center; */
	}
	.logo {
		/* margin: auto; */
		/* font-size: 20em; */
		background: url("./assets/img/logo.png");
		background-repeat: no-repeat;
  		background-size: 100% 100%;
		height: 150px;
		width: 180px;
		padding: 20px;
		margin-left: auto;
  		margin-right: auto;
		color: #000000b3;
		display: flex;
		/* align-items: center; */
	}
	.logo1 {
		background: url("./assets/img/banner.png");
		background-repeat: no-repeat;
  		background-size: 100% 100%;
		height: 50px;
		width: 500px;
		margin-left: auto;
  		margin-right: auto;
		display: flex;
		align-items: center;
	}

	.title{
		position: fixed;
		right: 0;
		top: 0;
		text-align: center;
		background-color: white;
		width: 100%;
		padding: 5px;
	}

	.footer {
		position: fixed;
		right: 0;
		bottom: 0;
		width: 100%;
		background-color: white;
		color: black;
		text-align: center;
	}
	
</style>

<body>
<div id="particles-js"></div>
	<!-- navbar -->
	
	<nav class="navbar">
		<div class="title">
			<h4>TIGAON TAX DECLERATION RECORD MANAGEMENT SYSTEM</h4>
		</div>
	</div>
	</nav>

	<!-- admin login -->
	<div id="login">
		<div class="card">
			<div class="row">
				<div class="column">
					<div class="pic1"> 
					<!-- <h4>TIGAON TAX DECLERATION RECORD MANAGEMENT SYSTEM<h4> -->
					</div>
				</div>
				<div class="column">
					<form id="login-form" class="login-form">
						<h4>Admin Login</h4>
						<div class="logo"></div>
						<div class="form-group">
							<label for="username" class="control-label">Username</label>
							<input type="text" id="username" name="username" class="form-control">
						</div>
						<div class="form-group">
							<label for="password" class="control-label">Password</label>
							<input type="password" id="password" name="password" class="form-control">
						</div>
						<center><button type="submit "class="button" name="btn_alogin">Login</button></center>
					</form>
				</div>
			</div>
		</div>
	</div>

	<!-- Foooter -->
	<div class="footer">
		<div class="copyright">
			<p>Copyright &copy; Designed & Developed by <a href="#">BSIT Students</a> 2022</p>
		</div>
	</div>
		  

		  <!-- Particle Js -->
	<link rel="stylesheet" href="./particles-js/dist/particle-style.css">
	<script src="./particles-js/dist/particle-script.js"></script>
	<script src="./particles-js/dist/particles.min.js"></script>
  </main>

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  

   

</body>
<script>
	
$(function() {
    
    $("[placeholder]").focus(function() {
        $(this).attr("data-text", $(this).attr("placeholder"));
        $(this).attr("placeholder", "");
        $(this).parent().find("i").css({
            "left": "20px",
            "color": "#57b846",
            "z-index": "2252"
        });
        $(this).css({ "padding-left": "47px", "border-color": "#DDD" });

    }).blur(function() {
        $(this).attr("placeholder", $(this).attr("data-text"));
        $(this).parent().find("i").css({
            "left": "35px",

        });
        $(this).css("padding-left", "65px")
    });



    var userError = true,

        passError = true;

    //Check Eorro On Submit
    $('.user').blur(function() {

        if ($(this).val().length < 4) {

            $(this).css('border', '1px solid #F00');
            $(this).parent().find("i").css("color", "#F00");
            userError = true;

        } else {

            $(this).css('border', '1px solid #080');
            userError = false;
        }
    })

    $('.pass').blur(function() {

        if ($(this).val().length == '') {

            $(this).css('border', '1px solid #F00');
            $(this).parent().find("i").css("color", "#F00");
            passError = true;

        } else {

            $(this).css('border', '1px solid #080');
            passError = false;
        }
    })


    $('.login-form').submit(function(e) {

        if (userError === true || passError === true) {

            e.preventDefault();
            $('.user , .pass').blur();
            $(this).find(".ic").css({
                "color": "red"
            });

        }
    });
});

</script>
<script>
	$('#login-form').submit(function(e){
		e.preventDefault()
		$('#login-form button[type="button"]').attr('disabled',true).html('Logging in...');
		if($(this).find('.alert-danger').length > 0 )
			$(this).find('.alert-danger').remove();
		$.ajax({
			url:'ajax.php?action=login',
			method:'POST',
			data:$(this).serialize(),
			error:err=>{
				console.log(err)
		$('#login-form button[type="button"]').removeAttr('disabled').html('Login');

			},
			success:function(resp){
				if(resp == 1){
					location.reload('index.php?page=home');
				}else{
					$('#login-form').prepend('<div class="alert alert-danger">Username or password is incorrect.</div>')
					$('#login-form button[type="button"]').removeAttr('disabled').html('Login');
				}
			}
		})
	})
</script>	

</html>