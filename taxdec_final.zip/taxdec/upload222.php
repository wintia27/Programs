<?php 
include('db_connect.php');
if(isset($_GET['id'])){
$qry = $conn->query("SELECT * FROM files where id=".$_GET['id']);
	if($qry->num_rows > 0){
		foreach($qry->fetch_array() as $k => $v){
			$meta[$k] = $v;
		}
	}
}

?> 
 <style>
    .container{
        background-color: white;
        margin-top: 40px;
        width: 600px;
        height: 610px;
        border: 1px solid lightblue;
        padding: 10px;
        box-shadow: 5px 5px 7px lightblue;
    }
    .drop-zone .icon{
      font-size: 100px;
      color: gray;
      height: 10vh;
      width: 10vw;
      align-items: center;
    }
    .drop-zone {
      max-width: 600px;
      height: 200px;
      padding: 25px;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      font-family: "Quicksand", sans-serif;
      font-weight: 500;
      font-size: 20px;
      cursor: pointer;
      color: #cccccc;
      border: 2px dashed black;
      border-radius: 10px;
    }

    .drop-zone--over {
      border-style: solid;
    }

    .drop-zone__input {
      display: none;
    }

    .drop-zone__thumb {
      width: 100%;
      height: 100%;
      border-radius: 10px;
      overflow: hidden;
      background-color: #cccccc;
      background-size: cover;
      position: relative;
    }

    .drop-zone__thumb::after {
      content: attr(data-label);
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      padding: 5px 0;
      color: #ffffff;
      background: rgba(0, 0, 0, 0.75);
      font-size: 14px;
      text-align: center;
    }


 </style>
 <?php include 'topbar.php' ?>
            <?php include 'navbar.php' ?>
        <div class="toast" id="alert_toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-body text-white">
            </div>
        </div>

        <!--**********************************
            Content body start 
        ***********************************-->

<div class="container">
	<form action="" method="POST" enctype="multipart/form-data">
		<!-- <div class="form-group">
			<label for="name" class="control-label">File Name</label>
			<input type="text" name="name" id="name" value="<?php echo isset($meta['name']) ? $meta['name'] :'' ?>" class="form-control">
		</div> -->
		<?php if(!isset($_GET['id']) || empty($_GET['id'])): ?>
		
	<?php endif; ?>
		<div class="form-group">
    <?php
						// If submit button is clicked
						if (isset($_POST['sbmit']))
						{
						// get name from the form when submitted
						$lname = $_POST['lname'];					
            $fname = $_POST['fname'];		
            $taxnum = $_POST['taxnum'];		
            $address = $_POST['address'];
            
						if (isset($_FILES['pdf_file']['name']))
						{
						// If the ‘pdf_file’ field has an attachment
							$file_name = $_FILES['pdf_file']['name'];
							$file_tmp = $_FILES['pdf_file']['tmp_name'];
							
							// Move the uploaded pdf file into the pdf folder
							move_uploaded_file($file_tmp,"assets/pdf/".$file_name);
							// Insert the submitted data from the form into the table
							$insertquery =
							"INSERT INTO taxdec(lname,fname,taxnum,address,file_name) VALUES('$lname','$fname','$taxnum','$address','$file_name')";
							
							// Execute insert query
							$iquery = mysqli_query($conn, $insertquery);	

								if ($iquery)
							{							
					?>											
								<div class=
								"alert alert-success alert-dismissible fade show text-center">
									<a class="close" data-dismiss="alert" aria-label="close">
									×
									</a>
									<strong href="upload.php">Success!</strong> Data submitted successfully.
								</div>
								<?php
								}
								else
								{
								?>
								<div class=
								"alert alert-danger alert-dismissible fade show text-center">
									<a class="close" data-dismiss="alert" aria-label="close">
									×
									</a>
									<strong>Failed!</strong> Try Again!
								</div>
								<?php
								}
							}
							else
							{
							?>
								<div class=
								"alert alert-danger alert-dismissible fade show text-center">
								<a class="close" data-dismiss="alert" aria-label="close">
									×
								</a>
								<strong>Failed!</strong> File must be uploaded in PDF format!
								</div>
							<?php
							}// end if
						}// end if
					?>
        <label for="" class="control-label">Last Name: </label>	
		<input type="text" name="lname" class="form-control" placeholder="eg. Dela Cruz" required ></input>
    <label for="" class="control-label">First Name: </label>	
		<input type="text" name="fname" class="form-control" placeholder="eg.Juan" required ></input>
    <label for="" class="control-label">Tax Declaration Number: </label>	
		<input type="text" name="taxnum" class="form-control" placeholder="eg. 2016-001-0001"  required ></input>
    <br>
    <div class="item5">
                    <div class="input-field">
                        <label for="" class="control-label">Owner Address:</label>
                        <select class="custom-select select2" name="address" required>
                            <option name="address"></option>
                            <?php 
                            $course = $conn->query("SELECT * FROM barangay order by address asc");
                            while($row=$course->fetch_assoc()):
                            ?>
                                <option name="address" value="<?php echo $row['bar_id'] ?>"><?php echo $row['address'] ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
                <br>
          <div class="drop-zone">
              <span class="drop-zone__prompt" >Drop file here or click to upload</span>
              <!---<div class="icon"><i class="fas fa-cloud-upload-alt" ></i></div>-->
              <input type="file" class="drop-zone__input" name="pdf_file" accept=".pdf" required>
          </div>

           <script src="assets/js/script.js"></script>
      <br>
            <button class="btn btn-primary"  type="submit" name="sbmit" value="sbmit">Upload</button>
            <button type="button" class="btn btn-secondary">Cancel</button>
     
		<div class="form-group" id="msg"></div>
	</form>
</div>
<script src="assets/js/formatter.js"></script>
<script>
  var contanct_no = new Formatter (document.getElementById('contact_no'), {
    'pattern': '{{9999}}-{{999}}-{{9999}}',
    'persistent': true
    });

    $('.select2').select2({
    placeholder:"Please Select Here",   
    allowClear: true,
   })

   function displayImg(input,_this) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#cimg').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}
</script>

