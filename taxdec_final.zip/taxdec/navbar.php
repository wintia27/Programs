<style>
	ul {
		list-style-type: none;
		margin: 0;
  		padding: 0;
	}
	.bg-black {
		
		background-color: #000000 !important;
	}	
</style>

<nav id="sidebar" class='mx-lt-5 bg-black' >
		
		<div class="sidebar-list">
			<ul>
				<a href="index.php?page=home" class="nav-item nav-home"><span class='icon-field'><i class="fa fa-home"></i></span> Home</a>
				<a href="index.php?page=upload" class="nav-item nav-upload"><span class='icon-field'><i class="fa fa-cloud-upload-alt"></i></span> Upload</a>
				<a href="index.php?page=record" class="nav-item nav-record"><span class='icon-field'><i class="fa fa-folder-open"></i></span> Record</a>
				<?php if($_SESSION['login_type'] == 1): ?>
				<a href="index.php?page=users" class="nav-item nav-users"><span class='icon-field'><i class="fa fa-users"></i></span> Users</a>
				<!-- <a href="index.php?page=searchfrm"></a> -->
				</ul>
			<?php endif; ?>
		</div>

</nav>
<script>
	$('.nav-<?php echo isset($_GET['page']) ? $_GET['page'] : '' ?>').addClass('active')
</script>