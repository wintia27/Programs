<style>
.footer {
  position: fixed;
  right: 0;
  bottom: 0;
  width: 85%;
  height: 30px;
  background-color: white;
  color: black;
  text-align: center;
}
.copyright{
  font-size: 14px;
  font-family: "Open Sans", sans-serif;
  padding-top: 5px;
}
</style>

<div class="footer">
    <div class="copyright">
        Copyright &copy; Designed & Developed by <a href="#">BSIT Students</a> 2022
    </div>
</div>
