// =============  Data Table - (Start) ================= //

$(document).ready(function(){
    
    var table = $('#example').DataTable({
        
        buttons:['copy', 'csv', 'excel', 'pdf', 'print'],
        
    });
    
    
    table.buttons().container()
    .appendTo('#example_wrapper .col-md-6:eq(0)');


    $(".filterhead").eq(0).each( function (i){
        var select = $('<select><option value=""></option></select>')
            .appendTo($(this).empty())
            .on('change',function (){
                var term = $(this).val();
                table.column(0).search(term,false,false).draw();   
                
            });
        table.column(0).data().unique().sort().each(function(d,j){
            select.append('<option value="'+d+'">'+d+'</option>')
        });

    });
    $(".filterhead").eq(2).each( function (i){
        var select = $('<select><option value=""></option></select>')
            .appendTo($(this).empty())
            .on('change',function (){
                var term = $(this).val();
                table.column(2).search(term,false,false).draw();   
                
            });
        table.column(2).data().unique().sort().each(function(d,j){
            select.append('<option value="'+d+'">'+d+'</option>')
        });

    });
    $(".filterhead").eq(3).each( function (i){
        var select = $('<select><option value=""></option></select>')
            .appendTo($(this).empty())
            .on('change',function (){
                var term = $(this).val();
                table.column(3).search(term,false,false).draw();   
                
            });
        table.column(3).data().unique().sort().each(function(d,j){
            select.append('<option value="'+d+'">'+d+'</option>')
        });

    });
    
 
    

});

// =============  Data Table - (End) ================= //
