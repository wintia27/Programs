
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    
    <title>Admin | Cinema Seat Reservation</title>

    <?php
        include('db_connect.php');
        session_start();
        if(!isset($_SESSION['login_id']))
            header('location:login.php');
        include('./header.php'); 
        ?>  
  <!-- <style type="text/css">
    
    .container{
      margin-top:10px;
      border:5px;
      border-color:black;
      
    }
    .table{
        background-color:#fafafa;
        -moz-box-shadow:0 3px 3px 0 rgba(0,0,0,.7);
        -webkit-box-shadow:0 3px 3px 0 rgba(0,0,0,.7);
        box-shadow:0 3px 3px 0 rgba(0,0,0,.7);
        border-radius:7;
    }
    .left_panel{
    overflow: hidden;
    border-radius: 7px;
    -webkit-box-shadow:0px 0px 20px 0px rgba(50,50,50,0.57);
    -moz-box-shadow:0px 0px 20px 0px rgba(50,50,50,0.57);
    height:auto;
}
  </style> -->
</head>

<body>
    <?php include 'topbar.php' ?>
	<?php include 'navbar.php' ?>
    <div class="toast" id="alert_toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-body text-white"></div>
    </div>

    <main id="view-panel" >
        <section>
        <div class="content-body">   
            <div class="container-fluid">
              <div class="container" >
                <div id="page-wrapper">
                <center>
                    <?php

                    //check for connection error
                    $sql = 'SELECT * FROM record WHERE tdrp_id ='.$_GET['id'];
                    $query=mysqli_query($conn,$sql);

                    while ($row=mysqli_fetch_array($query)){
                        echo '<tr>';
                        echo '<h1><td>'. $row['fname'].' '. $row['lname'].'</td></h1>';
                        echo '<h3><td>'. $row['taxnum'].'</td></h3>';
                        echo '<h3><td >'. $row['file_name'].'</td></h3>';
                    ?>
                        <embed type="application/pdf" src="assets/record/<?php echo $row['file_name'];?>" width="800" height="1000">
                        <!-- <embed type="application/pdf" src="./assets/uploads/<php echo $row['file_path'];?>#toolbar=0" width="800" height="1000"> -->
                    <?php
                        }
                    ?>
                </div>
            </div>
        </div>
        </section>
    </main>
</body>

</html>


