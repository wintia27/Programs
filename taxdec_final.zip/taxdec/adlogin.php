<?php
         session_start();
    
         $errors = [];
         
         $conn = new mysqli('localhost', 'root', '', 'fms_db');

        if(isset($_POST['btn_alogin']))
        { 
            $username = $_POST['username'];
            $password = $_POST['password'];

            $admin = mysqli_query($conn, "SELECT * from users where username = '$username' and password = '$password'");
            $numrow_admin = mysqli_num_rows($admin);

            if($numrow_admin > 0)
            {
                while($row = mysqli_fetch_array($admin)){
                  $_SESSION['role'] = "Administrator";
                  $_SESSION['userid'] = $row['admin_id'];
                  $_SESSION['username'] = $row['username'];
                }   
                if(isset($_SESSION['role'])){
                  $action = 'Adminstrator log in';
                  $iquery = mysqli_query($conn,"INSERT INTO logs (user_type,admin_id,logdate,action) values ('".$_SESSION['role']."','".$_SESSION['userid']."', NOW(), '".$action."')");
                }
                header ('location: index.php');
            }
            else
            { 
              echo '<script type="text/javascript">document.getElementById("error").innerHTML = "Invalid Account";</script>';
               
            }

        }
        
      ?> 