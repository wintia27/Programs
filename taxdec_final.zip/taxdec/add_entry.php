<?php
session_start();
require_once 'include.php';

        //check to see if the form was submitted
        if(isset($_POST['addBtn'])){
            $target_dir = "./uploads/pdf_directory/upload/";
            
            //get the form all data
            $title = isset($_POST['title']) ? $_POST['title'] : "";
            $year = isset($_POST['year']) ? $_POST['year'] : "";
            $authors = isset($_POST['authors']) ? $_POST['authors'] : "";
            $abstract = isset($_POST['abstract']) ? $_POST['abstract'] : "";
            $college = isset($_POST['college']) ? $_POST['college'] : "";
            $course = isset($_POST['course']) ? $_POST['course'] : "";
            $topic = isset($_POST['topic']) ? $_POST['topic'] : "";
            $keywords = isset($_POST['keywords']) ? $_POST['keywords'] : "";
            
            if (isset($_POST['addBtn'])) { // if save button on the form is clicked
                // name of the uploaded file
                $filename = $_FILES['upload']['name'];
            
                // destination of the file on the server
                $destination = 'uploads/pdf_directory/upload/' . $filename;
            
                // get the file extension
                $extension = pathinfo($filename, PATHINFO_EXTENSION);
            
                // the physical file on a temporary uploads directory on the server
                $file = $_FILES['upload']['tmp_name'];
                $size = $_FILES['upload']['size'];
            
                if (!in_array($extension, ['zip', 'pdf', 'docx'])) {
                    echo "You file extension must be .zip, .pdf or .docx";
                } elseif ($_FILES['upload']['size'] > 100000000) { // file shouldn't be larger than 100Megabyte
                    echo "File too large!";
                } else {
                    // move the uploaded (temporary) file to the specified destination
                    if (move_uploaded_file($file, $destination)) {
                        $sql = "INSERT INTO thesis_list (title, year, authors, abstract, college, course, topic, keywords, file_path) VALUES ('$title', '$year', '$authors', '$abstract', '$college', '$course', '$topic', '$keywords', '$filename')";
                        if (mysqli_query($conn, $sql)) {
                            echo "File uploaded successfully";
                        }
                    } else {
                        echo "Failed to upload file.";
                    }
                    
                }
                if (isset($_SESSION['role'])) {
                    $action = 'Adminstrator uploaded thesis named '.$title;
                    $iquery = mysqli_query($conn,"INSERT INTO logs (user_type,logdate,action) values ('".$_SESSION['role']."', NOW(), '".$action."')");
                }
                }
                
                header('location: ../upload.php');

            }
    ?>
    <script type="text/javascript">
        alert("Upload Successfull!");
        window.location = "../thesis-list.php";
		</script>