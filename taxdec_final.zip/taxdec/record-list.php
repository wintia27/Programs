<?php
       include('db_connect.php');
        ?>  

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    
    <!-- theme meta -->
    <meta name="theme-name" content="PTAMS" />
    <title>Thesis List</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/ptams_logo.png">
    <!-- Pignose Calender -->
    <link href="plugins/pg-calendar/css/pignose.calendar.min.css" rel="stylesheet">
    <!-- Chartist -->
    <link rel="stylesheet" href="plugins/chartist/css/chartist.min.css">
    <link rel="stylesheet" href="plugins/chartist-plugin-tooltips/css/chartist-plugin-tooltip.css">
    <!--icons-->
    <link href="icons/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="icons/icons/bootstrap-combined.no-icons.min.css" rel="stylesheet">

    <!-- Custom Stylesheet -->
    <link href="css-main/style.css" rel="stylesheet">
    
    <link href="css-main/style.css.map" rel="stylesheet">
    

    <!-- Morris Charts CSS -->
    <link href="thesis_list/css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="thesis_list/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
    <!-- Datatable -->
    <link href="css-main/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css">

  <style type="text/css">
    
    .container{
      margin-top:10px;
      border:5px;
      border-color:black;
      
    }
    .table{
        background-color:#fafafa;
        -moz-box-shadow:0 3px 3px 0 rgba(0,0,0,.7);
        -webkit-box-shadow:0 3px 3px 0 rgba(0,0,0,.7);
        box-shadow:0 3px 3px 0 rgba(0,0,0,.7);
        border-radius:7;
    }
    .left_panel{
    overflow: hidden;
    border-radius: 7px;
    -webkit-box-shadow:0px 0px 20px 0px rgba(50,50,50,0.57);
    -moz-box-shadow:0px 0px 20px 0px rgba(50,50,50,0.57);
    height:auto;
}
  </style>
</head>

<body>

        <section>
        <div class="content-body">   
            <div class="container-fluid">
              <h2 class="text-left">List of Thesis Uploaded</h2>
              <div class="container" >
              <div id="page-wrapper">

<div class="container-fluid">
 <div class="col-lg-12 left_panel">
            
            <div class="table-responsive">
                <table id="example" class="table table-bordered table-hover table-striped">
                    <thead>
                        <tr>
                            <th>Date Created</th>
                            <th>Title</th>
                            <th>Year</th>
                            <th>Author</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                     <?php                  
    $query = 'SELECT * FROM thesis_list ORDER BY date_created DESC';
        $result = mysqli_query($conn, $query) or die (mysqli_error($conn));
      
            while ($row = mysqli_fetch_assoc($result)) {
                                 
                echo '<tr>';
                echo '<td>'. $row['date_created'].'</td>';
                echo '<td>'. $row['title'].'</td>';
                echo '<td>'. $row['year'].'</td>';
                echo '<td>'. $row['authors'].'</td>';
                echo '<td> <a type="button" class="btn btn-xs btn-info" href="thesis_list/searchfrm.php?action=edit & id='.$row['thesis_id'] . '" ><i class="icon-eye-open"></i></a> ';
                echo ' <a  type="button" class="btn btn-xs btn-warning" style=" justify-items: center;" href="thesis_list/edit2.php?action=edit & id='.$row['thesis_id'] . '"><i class="icon-edit"></i></a> ';
                echo ' <a  type="button" class="btn btn-xs btn-primary " style="justify-items: center;"href="thesis_list/archive.php?action=edit & id='.$row['thesis_id'] . '"><i class="icon-archive"></i></a>';
                echo ' <a  type="button" class="btn btn-xs btn-danger" style="justify-items: center;"href="thesis_list/del.php?type=thesis_list&delete & id='.$row['thesis_id'] . '"><i class="icon-trash"></i> </a> </td>';
                echo '</tr> ';
    }
?> 
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
</div>
<!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper --> 
            <!-- #/ container -->
        </div>
           
        <!--**********************************
            Content body end
        ***********************************-->
   
        
        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright &copy; Designed & Developed by <a href="#">BSIT Students</a> 2022</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->
            </div> <!--**********************************
    
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="thesis_list/js/plugins/morris/raphael.min.js"></script>
    <script src="thesis_list/js/plugins/morris/morris.min.js"></script>
    <script src="thesis_list/js/plugins/morris/morris-data.js"></script>

    <!-- Datatables -->
    <script src="js/datatable/jquery.min.js"></script>  
    <script src="js/datatable/jquery.dataTables.min.js"></script>  
    <script src="js/datatable/dataTables.bootstrap.min.js"></script> 

    <!-- Report -->
    <script src="report/assets/js/bootstrap.bundle.min.js"></script>
    <script src="report/assets/js/jquery-3.6.0.min.js"></script>
    <script src="report/assets/js/datatables.min.js"></script>
    <script src="report/assets/js/pdfmake.min.js"></script>
    <script src="report/assets/js/vfs_fonts.js"></script>
    <script src="report/assets/js/custom.js"></script>
</section>
</body>

</html>
<script>  
    $(document).ready(function(){  
        $('#employee_data').DataTable();  
    }); 
</script>

