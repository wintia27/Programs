
<?php
	session_start();
			$tdrp_id= $_POST['tdrp_id'];
			$fname= $_POST['fname'];
			$lname=$_POST['lname'];
			$taxnum=$_POST['taxnum'];
			$barangay=$_POST['barangay'];
			$tdyear=$_POST['tdyear'];
			
	   include('db_connect.php');
		
	 			$query = 'UPDATE record set tdrp_id="'.$tdrp_id.'",
					fname ="'.$fname.'", lname="'.$lname.'",
					taxnum="'.$taxnum.'",barangay="'.$barangay.'", 
					tdyear="'.$tdyear.'" WHERE
					tdrp_id ="'.$tdrp_id.'"';
					$result = mysqli_query($conn, $query) or die(mysqli_error($conn));
?>


<!-- <script src="assets/js/sweetalert.min.js"></script>
	<script>	
		function submitForm(form){
			swal({
			title: "Good job!",
			text: "You clicked the button!",
			icon: "success",
			});
		}
		window.location = "index.php?page=record";
	</script> -->

	<!-- <script>
        function submitForm(form){
            swal({
                title: "Are you sure?",
                text: "This form will be submitted",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((isOkay) => {
                if (isOkay){
                    form.submit();
                }
            });
                return false;
        }
    </script> -->

	<!-- <script type="text/javascript">
        document.getElementById('updatealeart').addEventListener('click', function(){
            alert('Update Successful');
			window.location = "index.php?page=record";
        })
    </script> -->
	<script>
			alert('Update Successful');
			window.location = "index.php?page=record";
	</script>
	