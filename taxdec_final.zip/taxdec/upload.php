<?php
        include('db_connect.php');
?>  

<!DOCTYPE html>
<html lang="en">
        
<head>
    <style type="text/css">
    .form-style-7{
        max-width:600px;
        margin: 10px 10px 50px 250px;
        background:#fff;
        border-radius:10px;
        padding:20px 20px 20px 20px;
        font-family: Georgia, "Times New Roman", Times, serif;
        border: 6px solid #000;
    }
    
    .form-style-7 h1{
        display: block;
        text-align: center;
        padding: 0;
        margin: 0px 0px 20px 0px;
        color: #5C5C5C;
        font-size:x-large;
        
    }     
    .title {
        background: #454d55;
        max-width:1000px;
        padding: 20px 30px 15px 30px;
        /* border-radius: 10px 10px 0 0;
        -webkit-border-radius: 10px 10px 0 0;
        -moz-border-radius: 10px 10px 0 0; */
        color: #fff;
        /* text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.12); */
        font: normal 20px 'Bitter', serif;
        /* -moz-box-shadow: inset 0px 2px 2px 0px rgba(255, 255, 255, 0.17);
        -webkit-box-shadow: inset 0px 2px 2px 0px rgba(255, 255, 255, 0.17);
        box-shadow: inset 0px 2px 2px 0px rgba(255, 255, 255, 0.17); */
        border: 1px solid #036D19;
        text-align: center;
        margin-bottom: 10px;
    }
    .form-style-7 ul{
        list-style:none;
        padding:0;
        margin:0;	
    }
    .form-style-7 li{
        display: block;
        padding: 9px;
        border:1px solid #DDDDDD;
        margin-bottom: 30px;
        border-radius: 3px;
        /* margin: 0 -9px 30px -9px; */
    }
    .form-style-7 li:last-child{
        border:none;
        margin-bottom: 0px;
        text-align: center;
    }
    .form-style-7 li > .cln > label{
        display: block;
        float: left;
        margin-top: -19px;
        background: #FFFFFF;
        height: 30px;
        padding: 2px 5px 2px 5px;
        color: black;
        font-size: 15px;
        overflow: hidden;
        font-family: Arial, Helvetica, sans-serif;
    }
    .form-style-7 li > label{
        display: block;
        float: left;
        margin-top: -19px;
        background: #FFFFFF;
        height: 30px;
        padding: 2px 5px 2px 5px;
        color: black;
        font-size: 15px;
        overflow: hidden;
        font-family: Arial, Helvetica, sans-serif;
    }
    .form-style-7 input[type="text"],
    .form-style-7 input[type="date"],
    .form-style-7 input[type="datetime"],
    .form-style-7 input[type="email"],
    .form-style-7 input[type="number"],
    .form-style-7 input[type="search"],
    .form-style-7 input[type="time"],
    .form-style-7 input[type="url"],
    .form-style-7 input[type="password"],
    .form-style-7 textarea,
    .form-style-7 select 
    {
        box-sizing: border-box;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        width: 100%;
        display: block;
        outline: none;
        border: none;
        height: 25px;
        line-height: 25px;
        font-size: 16px;
        padding: 0;
        font-family: Georgia, "Times New Roman", Times, serif;
    }
        .form-style-7 input[type="text"]:focus,
        .form-style-7 input[type="date"]:focus,
        .form-style-7 input[type="datetime"]:focus,
        .form-style-7 input[type="email"]:focus,
        .form-style-7 input[type="number"]:focus,
        .form-style-7 input[type="search"]:focus,
        .form-style-7 input[type="time"]:focus,
        .form-style-7 input[type="url"]:focus,
        .form-style-7 input[type="password"]:focus,
        .form-style-7 textarea:focus,
        .form-style-7 select:focus 
    {
    }
    .form-style-7 li > span{
        background: #F3F3F3;
        display: block;
        padding: 3px;
        /* margin: 0 -9px -9px -9px; */
        text-align: center;
        color: #C0C0C0;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 15px;
    }
    .form-style-7 textarea{
        resize:none;
    }
    .form-style-7 input[type="submit"],
    .form-style-7 input[type="button"]{
        background: #2471FF;
        border: none;
        padding: 10px 20px 10px 20px;
        /* border-bottom: 3px solid #5994FF; */
        border-radius: 3px;
        color: #D2E2FF;
    }
    .form-style-7 input[type="submit"]:hover,
    .form-style-7 input[type="button"]:hover{
        background: #6B9FFF;
        color:#fff;
    }

    /* drag file or drop */
    .file-drop-area {
        /* border: 1px dashed #7c7db3;
        border-radius: 3px; */
        position: relative;
        width: 600px;
        max-width: 100%;
        margin: 0 auto;
        padding: 26px 20px 30px;
        -webkit-transition: 0.2s;
        transition: 0.2s;
        text-align: center;
    }
    .file-drop-area.is-active {
        background-color: #FFFFFF;
    }
    .file-drop-area:hover {
        background-color: #3E4E50;
        color: #FFFF;
    }

    .fake-btn {
        border: 2px solid #000000;
        border-radius: 3px;
        padding: 8px 15px;
        margin-right: 8px;
        font-size: 12px;
        text-transform: uppercase;
    }

    .file-msg {
        font-size: small;
        font-weight: 300;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        display: inline-block;
        max-width: calc(100% - 130px);
        vertical-align: middle;
    }

    .file-input {
        position: absolute;
        left: 0;
        top: 0;
        height: 100%;
        width: 100%;
        cursor: pointer;
        opacity: 0;
    }
    .file-input:focus {
        outline: none;
    }
    .form-style-7 li > .cln{
        width: 50%;
        float: left;
        /* border: 1px solid #DDDDDD; */
        /* display: block; */
        /* float: left; */

        background: #FFFFFF;
        /* height: 30px; */
        padding: 2px 5px 2px 5px;
        color: black;
        /* overflow: hidden; */
        /* font-family: Arial, Helvetica, sans-serif; */
    }

    select {
   -webkit-appearance:none;
   -moz-appearance:none;
   -ms-appearance:none;
   appearance:none;
   outline:0;
   box-shadow:none;
   border:0!important;
   /* background: #5c6664; */
   background-image: none;
   flex: 1;
   padding: 0 .5em;
   color: #000;
   cursor:pointer;
   font-size: 1em;
   font-family: 'Open Sans', sans-serif;
    }
    select::-ms-expand {
    display: none;
    }
    .select {
    position: relative;
    display: flex;
    width: 20em;
    height: 3em;
    line-height: 3;
    background: #5c6664;
    overflow: hidden;
    border-radius: .25em;
    }
    .select::after {
    content: "";
    position: absolute;
    top: 0;
    right: 0;
    padding: 0 1em;
    background: #000;
    cursor:pointer;
    pointer-events:none;
    transition:.25s all ease;
    }
    .select:hover::after {
    color: #23b499;
    }

    
    </style>
</head>

    <div class="container">
    <form action="" class="form-style-7" method="POST" name="" enctype="multipart/form-data">
        <?php if(!isset($_GET['id']) || empty($_GET['id'])): ?>
		
        <?php endif; ?>
            <div class="form-group">
        <?php
        // If submit button is clicked
        if (isset($_POST['submit']))
        {
        // get name from the form when submitted
        $fname = $_POST['fname'];					
        $lname = $_POST['lname'];		
        $taxnum = $_POST['taxnum'];		
        $barangay = $_POST['barangay'];

        if (isset($_FILES['pdf_file']['name']))
        {
        // If the ‘pdf_file’ field has an attachment
            $file_name = $_FILES['pdf_file']['name'];
            $file_tmp = $_FILES['pdf_file']['tmp_name'];
            
            // Move the uploaded pdf file into the pdf folder
            move_uploaded_file($file_tmp,"assets/record/".$file_name);
            // Insert the submitted data from the form into the table
            $insertquery =
            "INSERT INTO record(fname,lname,taxnum,barangay,file_name) VALUES('$fname','$lname','$taxnum','$barangay','$file_name')";
            
            // Execute insert query
            $iquery = mysqli_query($conn, $insertquery);	

                if ($iquery)
            {							
    ?>											
                <div class=
                "alert alert-success alert-dismissible fade show text-center">
                    <a class="close" data-dismiss="alert" aria-label="close">
                    ×
                    </a>
                    <strong href="upload.php">Success!</strong> Data submitted successfully.
                </div>
                <?php
                }
                else{
                ?>
                    <div class=
                    "alert alert-danger alert-dismissible fade show text-center">
                        <a class="close" data-dismiss="alert" aria-label="close">
                        ×
                        </a>
                        <strong>Failed!</strong> Try Again!
                    </div>
                <?php
                }
                }
                else
                {
                ?>
                    <div class=
                    "alert alert-danger alert-dismissible fade show text-center">
                    <a class="close" data-dismiss="alert" aria-label="close">
                        ×
                    </a>
                    <strong>Failed!</strong> File must be uploaded in PDF format!
                    </div>
                <?php
                }// end if
                }// end if
    ?>
            <div class="title">Tax Declaration Upload Form</div>
        <ul>
            <li><div class="cln">
                <label for="fname">First Name</label>
                <input type="text" name="fname" autofocus="" placeholder="e.g. Juan" maxlength="50" required></div>
            <div class="cln">
                <label for="lname">Last Name</label>
                <input type="text" name="lname" autofocus="" placeholder="e.g. Dela Cruz" maxlength="50" required></div>
            <span>Enter the owner name here</span></li>

            <li><label for="taxnum">Tax Declaration Number</label>
            <input type="text" name="taxnum" id="contact_no" autofocus="" maxlength="100" required>
            <span>Enter the tax decleration number here</span></li>
        
            <li><label for="barangay">Barangay</label>
            <select name="barangay" required>
                    <option selected disabled>Choose a Barangay </option><i class="uil uil-angle-down"></i>
                    <?php 
                    $batch = $conn->query("SELECT * FROM barangay_list order by barangay_id");
                    while($row=$batch->fetch_assoc()):
                    ?>
                    <option value="<?php echo $row['barangay_name'] ?>"><?php echo $row['barangay_name'] ?></option>
                    <?php endwhile; ?>
                </select>
            <span>Enter the barangay here</span></li>

            <li><label for="barangay">Year</label>
            <select name="barangay" required>
                    <option selected disabled>Choose Year</option>
                    <?php 
                    $batch = $conn->query("SELECT * FROM tax_year order by year_id");
                    while($row=$batch->fetch_assoc()):
                    ?>
                    <option value="<?php echo $row['year_td'] ?>"><?php echo $row['year_td'] ?></option>
                    <?php endwhile; ?>
                </select>
            <span>Enter the barangay here</span></li>
        
            
            <!-- <li><label for="bio">Upload File</label>

            <textarea name="bio" onkeyup="adjust_textarea(this)"></textarea>
            <span>Say something about yourself</span></li> -->

            <li><label for="bio">Upload File</label>
            <div class="file-drop-area">
                <span class="fake-btn">Choose files</span>
                <span class="file-msg js-set-number">or drag and drop files here</span>
                <input class="file-input" type="file" name="pdf_file" multiple>
            </div>
            <span>Upload file here</span></li>
            
            <li><input type="submit"  name="submit" value="Upload"></li>
        </ul>
        </form>
    </div>

</body>
    <script type="text/javascript">
    //auto expand textarea
    function adjust_textarea(h) {
        h.style.height = "20px";
        h.style.height = (h.scrollHeight)+"px";
    }
    var contanct_no = new Formatter (document.getElementById('contact_no'), {
    'pattern': '{{9999}}-{{999}}-{{9999}}',
    'persistent': true
    });

    // highlight drag area 
    var fileinput = document.querySelector('.file-input');
    var filedroparea = document.querySelector('.file-drop-area');
    var jssetnumber = document.querySelector('.js-set-number');
    fileinput.addEventListener('dragenter', isactive);
    fileinput.addEventListener('focus', isactive);
    fileinput.addEventListener('click', isactive);

    // back to normal state
    fileinput.addEventListener('dragleave', isactive);
    fileinput.addEventListener('blur', isactive);
    fileinput.addEventListener('drop', isactive);

    // add Class
    function isactive() {
    filedroparea.classList.add('is-active');
    }

    // change inner text
    fileinput.addEventListener('change', function() {
    var count = fileinput.files.length;
    if (count === 1) {
        // if single file then show file name
        jssetnumber.innerText = fileinput.value.split('\\').pop();
    } else {
        // otherwise show number of files
        jssetnumber.innerText = count + ' files selected';
    }
    });
    </script>
</html>