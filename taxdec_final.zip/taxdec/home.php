<style>
	.custom-menu {
        z-index: 1000;
	    position: absolute;
	    background-color: #ffffff;
	    border: 1px solid #0000001c;
	    border-radius: 5px;
	    padding: 8px;
	    min-width: 13vw;
}
a.custom-menu-list {
    width: 100%;
    display: flex;
    color: #4c4b4b;
    font-weight: 600;
    font-size: 1em;
    padding: 1px 11px;
}
	span.card-icon {
    position: absolute;
    font-size: 3em;
    bottom: .2em;
    color: #ffffff80;
}
.file-item{
	cursor: pointer;
}
a.custom-menu-list:hover,.file-item:hover,.file-item.active {
    background: #80808024;
}
table th,td{
	/*border-left:1px solid gray;*/
}
a.custom-menu-list span.icon{
		width:1em;
		margin-right: 5px
}
.bg-tax {
  	background-color: #036D19 !important;
}

</style>

<div class="containe-fluid">
	<?php include('db_connect.php') ;
	$files = $conn->query("SELECT f.*,u.name as uname FROM files f inner join users u on u.id = f.user_id where  f.is_public = 1 order by date(f.date_updated) desc");
?>
	<!-- ROW 1 -->

	<h3 class="font-weight-bold text-center col-lg-12">DASHBOARD</h3>
	<div class="row">
		<div class="col-lg-12">
			<a href="index.php?page=record">
			<div class="card col-md-3 offset-1 bg-tax float-left">
				<div class="card-body text-white">
					<h4><b>Poblacion</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Poblacion"')->num_rows ?></b></h3>
				</div>
			</div></a>
			<a href="index.php?page=record">
			<div class="card col-md-3 bg-tax ml-4 float-left">
				<div class="card-body text-white">
					<h4><b>Abo</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Abo"')->num_rows ?></b></h3>
				</div>
			</div></a>
			<a href="index.php?page=record">
			<div class="card col-md-3 bg-tax ml-4 float-left">
				<div class="card-body text-white">
					<h4><b>Cabalinadan</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Cabalinadan"')->num_rows ?></b></h3>
				</div>
			</div></a>
		</div>
	</div><br>
	<!-- ROW 2 -->
	<div class="row">
		<div class="col-lg-12">
			<a href="index.php?page=record">
			<div class="card col-md-3 offset-1 bg-tax float-left">
				<div class="card-body text-white">
					<h4><b>Caraycayon</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Caraycayon"')->num_rows ?></b></h3>
				</div>
			</div></a>
			<a href="index.php?page=record">
			<div class="card col-md-3 bg-tax ml-4 float-left">
				<div class="card-body text-white">
					<h4><b>Casuna</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Casuna"')->num_rows ?></b></h3>
				</div>
			</div></a>
			<a href="index.php?page=record">
			<div class="card col-md-3 bg-tax ml-4 float-left">
				<div class="card-body text-white">
					<h4><b>Consocep</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Consocep"')->num_rows ?></b></h3>
				</div>
			</div></a>
		</div>
	</div><br>
	<!-- ROW 3 -->
	<div class="row">
		<div class="col-lg-12">
			<a href="index.php?page=record">
			<div class="card col-md-3 offset-1 bg-tax float-left">
				<div class="card-body text-white">
					<h4><b>Coyaoyao</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Coyaoyao"')->num_rows ?></b></h3>
				</div>
			</div></a>
			<a href="index.php?page=record">
			<div class="card col-md-3 bg-tax ml-4 float-left">
				<div class="card-body text-white">
					<h4><b>Gaao</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Gaao"')->num_rows ?></b></h3>
				</div>
			</div></a>
			<a href="index.php?page=record">
			<div class="card col-md-3 bg-tax ml-4 float-left">
				<div class="card-body text-white">
					<h4><b>Gubat</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Gubat"')->num_rows ?></b></h3>
				</div>
			</div></a>
		</div>
	</div><br>
	<!-- row4 -->
	<div class="row">
		<div class="col-lg-12">
			<a href="index.php?page=record">
			<div class="card col-md-3 offset-1 bg-tax float-left">
				<div class="card-body text-white">
					<h4><b>Hingaroy</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Hingaroy"')->num_rows ?></b></h3>
				</div>
			</div></a>
			<a href="index.php?page=record">
			<div class="card col-md-3 bg-tax ml-4 float-left">
				<div class="card-body text-white">
					<h4><b>Huyonhuyon</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Huyonhuyon"')->num_rows ?></b></h3>
				</div>
			</div></a>
			<a href="index.php?page=record">
			<div class="card col-md-3 bg-tax ml-4 float-left">
				<div class="card-body text-white">
					<h4><b>Libod</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Libod"')->num_rows ?></b></h3>
				</div>
			</div></a>
		</div>
	</div><br>

	<!-- row5 -->
	<div class="row">
		<div class="col-lg-12">
			<a href="index.php?page=record">
			<div class="card col-md-3 offset-1 bg-tax float-left">
				<div class="card-body text-white">
					<h4><b>Mabalodbalod</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Mabalodbalod"')->num_rows ?></b></h3>
				</div>
			</div></a>
			<a href="index.php?page=record">
			<div class="card col-md-3 bg-tax ml-4 float-left">
				<div class="card-body text-white">
					<h4><b>May Anao</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="May Anao"')->num_rows ?></b></h3>
				</div>
			</div></a>
			<a href="index.php?page=record">
			<div class="card col-md-3 bg-tax ml-4 float-left">
				<div class="card-body text-white">
					<h4><b>Panagan</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Panagan"')->num_rows ?></b></h3>
				</div>
			</div></a>
		</div>
	</div><br>

	<!-- row6 -->
	<div class="row">
		<div class="col-lg-12">
			<a href="index.php?page=record">
			<div class="card col-md-3 offset-1 bg-tax float-left">
				<div class="card-body text-white">
					<h4><b>Salvacion</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Salvacion"')->num_rows ?></b></h3>
				</div>
			</div></a>
			<a href="index.php?page=record">
			<div class="card col-md-3 bg-tax ml-4 float-left">
				<div class="card-body text-white">
					<h4><b>San Antonio</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="San Antonio"')->num_rows ?></b></h3>
				</div>
			</div></a>
			<a href="index.php?page=record">
			<div class="card col-md-3 bg-tax ml-4 float-left">
				<div class="card-body text-white">
					<h4><b>San Francisco</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="San Francisco"')->num_rows ?></b></h3>
				</div>
			</div></a>
		</div>
	</div><br>

	<!-- row7 -->
	<div class="row">
		<div class="col-lg-12">
			<a href="index.php?page=record">
			<div class="card col-md-3 offset-1 bg-tax float-left">
				<div class="card-body text-white">
					<h4><b>San Miguel</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="San Miguel"')->num_rows ?></b></h3>
				</div>
			</div></a>
			<a href="index.php?page=record">
			<div class="card col-md-3 bg-tax ml-4 float-left">
				<div class="card-body text-white">
					<h4><b>San Rafael</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="San Rafael"')->num_rows ?></b></h3>
				</div>
			</div></a>
			<a href="index.php?page=record">
			<div class="card col-md-3 bg-tax ml-4 float-left">
				<div class="card-body text-white">
					<h4><b>Talajongon</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Talajongon"')->num_rows ?></b></h3>
				</div>
			</div></a>
		</div>
	</div><br>

	<!-- row7 -->
	<div class="row">
		<div class="col-lg-12">
			<a href="index.php?page=record">
			<div class="card col-md-3 offset-1 bg-tax float-left">
				<div class="card-body text-white">
					<h4><b>Tinawagan</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Tinawagan"')->num_rows ?></b></h3>
				</div>
			</div></a>
			<a href="index.php?page=record">
			<div class="card col-md-3 bg-tax ml-4 float-left">
				<div class="card-body text-white">
					<h4><b>Vinagre</b></h4>
					<hr>
					<span class="card-icon"><i class="fa fa-file-archive"></i></span>
					<h3 class="text-right"><b><?php echo $conn->query('SELECT * FROM record WHERE barangay="Vinagre"')->num_rows ?></b></h3>
				</div>
			</div></a>
			
		</div>
	</div><br>


</div>
<div id="menu-file-clone" style="display: none;">
	<a href="javascript:void(0)" class="custom-menu-list file-option download"><span><i class="fa fa-download"></i> </span>Download</a>
</div>
<script>
	//FILE
	$('.file-item').bind("contextmenu", function(event) { 
    event.preventDefault();

    $('.file-item').removeClass('active')
    $(this).addClass('active')
    $("div.custom-menu").hide();
    var custom =$("<div class='custom-menu file'></div>")
        custom.append($('#menu-file-clone').html())
        custom.find('.download').attr('data-id',$(this).attr('data-id'))
    custom.appendTo("body")
	custom.css({top: event.pageY + "px", left: event.pageX + "px"});

	
	$("div.file.custom-menu .download").click(function(e){
		e.preventDefault()
		window.open('download.php?id='+$(this).attr('data-id'))
	})

	
})
	$(document).bind("click", function(event) {
    $("div.custom-menu").hide();
    $('#file-item').removeClass('active')

});
	$(document).keyup(function(e){

    if(e.keyCode === 27){
        $("div.custom-menu").hide();
    $('#file-item').removeClass('active')

    }
})
</script>