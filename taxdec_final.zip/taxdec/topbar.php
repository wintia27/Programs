<style>
.logo {
    /* margin: auto; */
    font-size: 20px;
    background: white;
    /* padding: 5px 11px; */
    border-radius: 50% 50%;
    color: #000000b3;
}
.log{
	width: 60px;
	height: 60px;
}
.bg-black {
	background-color: #000000 !important;
}
.admin {
  flex: 1;
  text-decoration: none;
  outline: none;
  text-align: center;
  line-height: 3;
  /* text-transform: uppercase; */
}
</style>

<nav class="navbar navbar-dark bg-black fixed-top " style="padding:0;">
  <div class="container-fluid mt-2 mb-2">
  	<div class="col-lg-12">
  		<div class="col-md-1 float-left" style="display: flex;">
  			<div class="logo">
  				<!-- <i class="fa fa-share-alt"></i> -->
				<img class="log" src="./assets/img/tlogo.png">
  			</div>
  		</div>
	  	<div class="col-md-2 float-right admin">
	  		<a href="ajax.php?action=logout" style="color: white;"><?php echo $_SESSION['login_name'] ?> <i class="fa fa-power-off"></i></a>
	    </div>
    </div>
  </div>
  
</nav>