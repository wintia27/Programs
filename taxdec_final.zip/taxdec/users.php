<?php
       include('db_connect.php');
        ?>  

<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="assets/datatable1/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/datatable1/css/datatables.min.css">
    <link rel="stylesheet" href="assets/datatable1/css/style.css">

  <style type="text/css">
    .container{
      margin-top:10px;
      border:5px;
      border-color:black;
      
    }
    .table{
        background-color:#fafafa;
        -moz-box-shadow:0 3px 3px 0 rgba(0,0,0,.7);
        -webkit-box-shadow:0 3px 3px 0 rgba(0,0,0,.7);
        box-shadow:0 3px 3px 0 rgba(0,0,0,.7);
        border-radius:7;
    }
    .left_panel{
        overflow: hidden;
        border-radius: 7px;
        -webkit-box-shadow:0px 0px 20px 0px rgba(50,50,50,0.57);
        -moz-box-shadow:0px 0px 20px 0px rgba(50,50,50,0.57);
        height:auto;
        width: 80px;
    }

    /* .filterhead{
        width:50px;
    } */
  </style>
</head>

<body>
<section>
    <div class="content-body">   
        <div class="container-fluid">
            <div class="container">
				<div class="row">
					<div class="col-lg-11">
							<button class="btn-primary float-right btn-sm" id="new_user"><i class="fa fa-plus"></i> New user</button>
					</div>
				</div>
                <div class="row">
                    <div class="col-12">
                        <div class="data_table">
							<table id="employee_data" class="table table-bordered table-striped">
								<thead>
									<tr class="table-dark">
										<th class="text-center">#</th>
										<th class="text-center">Name</th>
										<th class="text-center">Username</th>
										<th class="text-center">User Type</th>
										<th class="text-center">Action</th>
									</tr>
								</thead>
								<tbody>
								<?php
									include 'db_connect.php';
									$users = $conn->query("SELECT * FROM users order by name asc");
									$i = 1;
									while($row= $users->fetch_assoc()):
								?>
									<tr>
										<td>
											<?php echo $i++ ?>
										</td>
										<td>
											<?php echo $row['name'] ?>
										</td>
										<td>
											<?php echo $row['username'] ?>
										</td>
										<td>
											<?php 
												$admin = 'Admin';
												$user = 'User';

												if($row['type'] == 1){
													echo $admin;
												} elseif($row['type'] == 2){
													echo $user;
												}
											?>
										</td>
										<td>
											<center>
													<div class="btn-group">
													<button type="button" class="btn btn-primary">Action</button>
													<button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														<span class="sr-only">Toggle Dropdown</span>
													</button>
													<div class="dropdown-menu">
														<a class="dropdown-item edit_user" href="javascript:void(0)" data-id = '<?php echo $row['id'] ?>'>Edit</a>
														<div class="dropdown-divider"></div>
														<a class="dropdown-item delete_user" href="javascript:void(0)" data-id = '<?php echo $row['id'] ?>'>Delete</a>
													</div>
													</div>
													</center>
										</td>
									</tr>
									<?php endwhile; ?>
									</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<script>
	
$('#new_user').click(function(){
	uni_modal('New User','manage_user.php')
})
$('.edit_user').click(function(){
	uni_modal('Edit User','manage_user.php?id='+$(this).attr('data-id'))
})

</script>
<script>  
    $(document).ready(function(){  
        $('#employee_data').DataTable();  
    }); 
</script> 