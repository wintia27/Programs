<style type="text/css">
	.avatar {
	    display: flex;
	    border-radius: 100%;
	    width: 200px;
	    height: 200px;
	    align-items: center;
	    justify-content: center;
	    /* border: 3px solid; */
	    padding: 5px;
	}
	.avatar img {
	    max-width: calc(100%);
	    max-height: calc(100%);
	    border-radius: 100%;
	}
	p{
		margin:unset;
	}
	#uni_modal .modal-footer{
		display: none
	}
	#uni_modal .modal-footer.display{
		display: block
	}
</style>
<div class="container-fluid">
    <div class="col-lg-12">
		<div>
			<center>
				<p>File Successfully uploaded</p>
			</center>
		</div>
	</div>
</div>
	<div class="row">
		<div class="col-lg-12">
			<a href="index.php"><button class="btn float-right btn-success" type="button">Done</button></a>
		</div>
	</div>
</div>
